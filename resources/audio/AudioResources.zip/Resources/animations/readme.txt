You can place scripts for animations in this folder.

See http://www.splashkit.io/articles/guides/tags/animations/animation/
